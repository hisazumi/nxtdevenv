#define INTEGER_ONLY
#include "vprintf.c"
