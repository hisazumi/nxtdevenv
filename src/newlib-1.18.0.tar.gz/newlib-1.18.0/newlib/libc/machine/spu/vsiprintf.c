#define INTEGER_ONLY
#include "vsprintf.c"
